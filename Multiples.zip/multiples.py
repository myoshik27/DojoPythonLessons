for count in range(1,1001):
	if count%2 == 1:
		print count
	else:
		continue