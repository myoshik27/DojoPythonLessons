for count in range(0,1000000):
	if count%5 == 0:
		print count
	else:
		continue